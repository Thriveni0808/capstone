import React, { Component } from "react";
import { withRouter } from "react-router";
class Board extends Component {
    render() {
        return (
            <>
            <h2>dashboard</h2>
           
         
            </>
        );
    }
}
export default withRouter(Board);