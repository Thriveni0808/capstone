import React, { Component } from "react";
import { withRouter } from "react-router";
class Order extends Component {
    render() {
        return (
            <>
            <h2>order</h2>
            
            </>
        );
    }
}
export default withRouter(Order);