import React, { Component } from "react";
import { Redirect, Switch, Route, Link } from "react-router-dom";
import { withRouter } from "react-router";
import "./Dashboard.css";
import Order from "./Order";
import Board from "./board";

class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      islogout: false
    };
  }
  signOut = () => {
    localStorage.removeItem("token");
    this.setState({
      islogout: true
    });
  };
  render() {
    if (this.state.islogout) {
      return <Redirect to="/login" />;
    }
    const { match } = this.props;
    return (
      <div className="home">
        <ul>
          <li>
            <Link to={`${match.path}`}>Home</Link>
          </li>
          <li>
            <Link to={`${match.path}/Order`}>Order</Link>
          </li>
          <li>
            <Link to={`${match.path}/board`}>Dashboard</Link>
          </li>
          <li className="push-right">
            <button onClick={this.signOut} href="#" class="btn btn-primary btn-block btn-large">
              Sign Out
            </button>
          </li>
        </ul>
        <main role="main">
          <div >
          <Switch>
              <Route path={`${match.path}/Order`}>
                <Order />
              </Route>
              <Route path={`${match.path}/board`}>
                <Board />
              </Route>
              <h2>hello</h2>
              
            </Switch>
          </div>
        </main>
      </div>
    );
  }
}
 
export default withRouter(Dashboard);